const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, BorderStyle } = require('docx');
const fs = require('fs');

const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 24 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: "Arial" },
        paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: "Arial" },
        paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 1 } },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
      }
    },
    children: [
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Population Pharmacokinetic Analysis Report")] }),
      new Paragraph({ children: [new TextRun({ text: "Sponsor: Acme Pharma  |  Analyst: Jane Doe  |  Date: 2025-03-01", italics: true, color: "666666" })] }),
      new Paragraph({ children: [new TextRun("")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("1. Introduction")] }),
      new Paragraph({ children: [new TextRun("This report describes the population pharmacokinetic (PopPK) analysis performed for Drug XYZ. The analysis was conducted using NONMEM v7.5.")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("2. Results")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("2.1 Goodness of Fit")] }),
      new Paragraph({ children: [new TextRun("The following figure presents the goodness-of-fit diagnostic plots for the base model:")] }),
      new Paragraph({ children: [new TextRun("{{FIG_01_GOF_BASE}}")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("2.2 Visual Predictive Check")] }),
      new Paragraph({ children: [new TextRun("The VPC plot confirms the final model adequately describes the observed data:")] }),
      new Paragraph({ children: [new TextRun("{{FIG_02_VPC_FINAL}}")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("2.3 Parameter Uncertainty")] }),
      new Paragraph({ children: [new TextRun("Bootstrap results illustrating parameter uncertainty are shown below:")] }),
      new Paragraph({ children: [new TextRun("{{FIG_03_PARAM_UNCERT}}")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("3. Conclusions")] }),
      new Paragraph({ children: [new TextRun("The two-compartment model with first-order absorption adequately described the data. All parameters were estimated with good precision.")] }),
    ]
  }]
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync('/home/claude/poppk-demo/PopPK_Template.docx', buf);
  console.log('Template created: PopPK_Template.docx');
});
