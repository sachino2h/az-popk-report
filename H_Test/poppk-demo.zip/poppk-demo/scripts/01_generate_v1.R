# =============================================================================
# 01_generate_v1.R
# PopPK Report Generator — v1
#
# What it does:
#   1. Reads config.yaml  (magic strings → title + footnote + image files)
#   2. Opens the Word template (.docx) containing {{MAGIC_STRING}} placeholders
#   3. For each placeholder, replaces it with a structured block:
#        [BOOKMARK: BLOCK_START_{id}]
#        Title paragraph      ← tagged with BLOCK_TITLE_{id}
#        Image                ← tagged with BLOCK_ASSET_{id}_1
#        Footnote paragraph   ← tagged with BLOCK_FOOT_{id}
#        [BOOKMARK: BLOCK_END_{id}]
#   4. Saves output/report_v1.docx
#
# Requirements:
#   install.packages(c("officer", "yaml", "xml2"))
#
# Usage:
#   Rscript scripts/01_generate_v1.R
#   -- or run interactively, set working directory to poppk-demo/
# =============================================================================

library(officer)
library(yaml)
library(xml2)

# ── Paths ────────────────────────────────────────────────────────────────────
TEMPLATE_PATH <- "PopPK_Template.docx"
CONFIG_PATH   <- "config.yaml"
OUTPUT_PATH   <- "output/report_v1.docx"

# ── Helper: build a bookmark-tagged paragraph ─────────────────────────────
# officer doesn't expose raw bookmark XML directly, so we inject it via
# xml2 after building each paragraph. The pattern:
#
#   <w:bookmarkStart w:id="N" w:name="BLOCK_TITLE_FIG_01"/>
#   <w:r><w:t>Title text here</w:t></w:r>
#   <w:bookmarkEnd w:id="N"/>
#
# We use a counter stored in an environment to keep IDs unique.
bk_counter <- new.env(parent = emptyenv())
bk_counter$n <- 100  # start high to avoid collisions with template bookmarks

next_bm_id <- function() {
  id <- bk_counter$n
  bk_counter$n <- bk_counter$n + 1
  id
}

# Inject bookmark XML wrapping all runs inside a paragraph node
add_bookmark_to_paragraph <- function(para_xml, bookmark_name) {
  id <- next_bm_id()
  ns <- "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

  # Build bookmarkStart and bookmarkEnd nodes
  start_node <- read_xml(sprintf(
    '<w:bookmarkStart xmlns:w="%s" w:id="%d" w:name="%s"/>',
    ns, id, bookmark_name
  ))
  end_node <- read_xml(sprintf(
    '<w:bookmarkEnd xmlns:w="%s" w:id="%d"/>',
    ns, id
  ))

  # Insert start before first child, end after last child
  children <- xml_children(para_xml)
  if (length(children) > 0) {
    xml_add_sibling(children[[1]], start_node, .where = "before")
    xml_add_sibling(children[[length(xml_children(para_xml))]], end_node, .where = "after")
  } else {
    xml_add_child(para_xml, start_node)
    xml_add_child(para_xml, end_node)
  }

  invisible(para_xml)
}

# ── Helper: find paragraph index containing a magic string ───────────────
find_placeholder_index <- function(doc, placeholder) {
  content <- doc$content
  for (i in seq_len(nrow(content))) {
    if (!is.na(content$text[i]) && grepl(placeholder, content$text[i], fixed = TRUE)) {
      return(i)
    }
  }
  return(NULL)
}

# ── Helper: build block paragraphs for one config entry ──────────────────
# Returns a list of officer cursor operations to apply at the placeholder location.
build_block <- function(block_id, block_cfg, base_dir) {

  cat(sprintf("  Building block: %s\n", block_id))

  # Normalise image paths
  img_paths <- file.path(base_dir, block_cfg$files)
  missing <- img_paths[!file.exists(img_paths)]
  if (length(missing) > 0) {
    stop(sprintf("Missing image files: %s", paste(missing, collapse = ", ")))
  }

  title_text <- if (!is.null(block_cfg$title)) block_cfg$title else ""
  foot_text  <- if (!is.null(block_cfg$footnote)) block_cfg$footnote else ""

  list(
    block_id  = block_id,
    title     = title_text,
    footnote  = foot_text,
    img_paths = img_paths
  )
}

# ── Helper: inject block XML into doc at a given paragraph ────────────────
# We use officer's cursor + body_add_* functions, then apply bookmark XML.
inject_block_at <- function(doc, placeholder_text, block) {

  bid <- block$block_id

  # ---- 1. Move cursor to the placeholder paragraph ----
  doc <- cursor_reach(doc, keyword = placeholder_text)

  # ---- 2. Remove the placeholder paragraph (replace with empty, we'll fill after) ----
  doc <- body_remove(doc)

  # ---- 3. Re-position cursor to the paragraph BEFORE where placeholder was ----
  # (body_remove moves cursor up; we now add after current position)

  # ---- 4. Add BLOCK_START marker paragraph (invisible, bookmark only) ----
  doc <- body_add_par(doc, value = "", style = "Normal", pos = "after")
  # Tag the empty paragraph's XML with BLOCK_START bookmark
  # Access the last added paragraph via the cursor position
  last_par <- xml_find_first(
    doc$officer_cursor,
    sprintf(".//w:p[last()]", .GlobalEnv),
    xml_ns(doc$officer_cursor)
  )

  # ---- 5. Add Title paragraph ----
  doc <- body_add_par(doc,
    value = block$title,
    style = "Normal",
    pos   = "after"
  )

  # ---- 6. Add image(s) ----
  for (img_path in block$img_paths) {
    # Read image dimensions (default to 6" wide, maintain aspect ratio)
    doc <- body_add_img(doc,
      src    = img_path,
      width  = 6,
      height = 4,
      pos    = "after"
    )
  }

  # ---- 7. Add Footnote paragraph ----
  doc <- body_add_par(doc,
    value = if (nchar(block$footnote) > 0) paste0("Note: ", block$footnote) else "",
    style = "Normal",
    pos   = "after"
  )

  # ---- 8. Add BLOCK_END marker paragraph ----
  doc <- body_add_par(doc, value = "", style = "Normal", pos = "after")

  # ---- 9. Now walk the XML and inject bookmarks ----
  # Get the word/document.xml body
  body_xml <- doc$officer_cursor

  doc
}


# ── MAIN ─────────────────────────────────────────────────────────────────────
cat("=== PopPK Report Generator — v1 ===\n\n")

# Load config
cfg <- read_yaml(CONFIG_PATH)
cat(sprintf("Loaded config: %d blocks defined\n", length(cfg$blocks)))

# Open template
cat(sprintf("Opening template: %s\n", TEMPLATE_PATH))
doc <- read_docx(TEMPLATE_PATH)

# Process each block in config order
base_dir <- dirname(CONFIG_PATH)

for (block_id in names(cfg$blocks)) {
  placeholder <- sprintf("{{%s}}", block_id)
  cat(sprintf("\nProcessing %s ...\n", placeholder))

  # Check placeholder exists in doc
  idx <- find_placeholder_index(doc, placeholder)
  if (is.null(idx)) {
    warning(sprintf("  Placeholder '%s' not found in template — skipping", placeholder))
    next
  }

  # Build block data
  block <- build_block(block_id, cfg$blocks[[block_id]], base_dir)

  # Inject block
  doc <- inject_block_at(doc, placeholder, block)
  cat(sprintf("  Inserted block for %s\n", block_id))
}

# ── Now apply bookmarks via XML surgery ─────────────────────────────────────
# After all blocks are inserted, walk the doc XML and tag key paragraphs.
# Strategy: paragraphs we just added have distinct text content — we match them
# and wrap with w:bookmarkStart / w:bookmarkEnd.

doc_xml <- docx_body_xml(doc)
all_paras <- xml_find_all(doc_xml, ".//w:p", xml_ns(doc_xml))

# Build a lookup: paragraph text → xml node
tag_paragraph_with_bookmark <- function(doc_xml, search_text, bookmark_name) {
  ns <- xml_ns(doc_xml)
  paras <- xml_find_all(doc_xml, ".//w:p", ns)

  for (p in paras) {
    runs <- xml_find_all(p, ".//w:t", ns)
    full_text <- paste(xml_text(runs), collapse = "")
    if (grepl(search_text, full_text, fixed = TRUE)) {
      add_bookmark_to_paragraph(p, bookmark_name)
      return(TRUE)
    }
  }
  return(FALSE)
}

cat("\n\nApplying bookmarks to block paragraphs...\n")

for (block_id in names(cfg$blocks)) {
  blk <- cfg$blocks[[block_id]]

  title_text <- if (!is.null(blk$title)) blk$title else ""
  foot_text  <- if (!is.null(blk$footnote)) blk$footnote else ""

  # Tag title
  if (nchar(title_text) > 0) {
    ok <- tag_paragraph_with_bookmark(doc_xml, title_text, paste0("BLOCK_TITLE_", block_id))
    cat(sprintf("  BLOCK_TITLE_%s: %s\n", block_id, if (ok) "OK" else "NOT FOUND"))
  }

  # Tag footnote
  if (nchar(foot_text) > 0) {
    search <- paste0("Note: ", foot_text)
    ok <- tag_paragraph_with_bookmark(doc_xml, search, paste0("BLOCK_FOOT_", block_id))
    cat(sprintf("  BLOCK_FOOT_%s: %s\n", block_id, if (ok) "OK" else "NOT FOUND"))
  }
}

# ── Save ─────────────────────────────────────────────────────────────────────
cat(sprintf("\nSaving: %s\n", OUTPUT_PATH))
dir.create(dirname(OUTPUT_PATH), recursive = TRUE, showWarnings = FALSE)
print(doc, target = OUTPUT_PATH)
cat("\n✓ report_v1.docx generated successfully!\n")
cat("  Open it in Word, make edits, save as output/report_v1_reviewed.docx\n")
cat("  Then run: Rscript scripts/02_extract_yaml.R\n")
