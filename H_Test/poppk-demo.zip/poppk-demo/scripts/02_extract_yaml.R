# =============================================================================
# 02_extract_yaml.R
# PopPK Report — Extract current state from reviewed .docx
#
# What it does:
#   1. Opens the reviewed Word document (after human edits)
#   2. Scans the document XML for bookmark tags:
#        BLOCK_TITLE_{id}  → reads the paragraph text as current title
#        BLOCK_FOOT_{id}   → reads the paragraph text as current footnote
#   3. Compares found block IDs against the original config.yaml
#   4. Outputs config_extracted_v2.yaml reflecting current state:
#        - Blocks still present: title/footnote as they now read in the doc
#        - Blocks missing: noted with a comment (implicitly deleted)
#
# Requirements:
#   install.packages(c("officer", "yaml", "xml2"))
#
# Usage:
#   Rscript scripts/02_extract_yaml.R
#   -- or run interactively, set working directory to poppk-demo/
# =============================================================================

library(officer)
library(yaml)
library(xml2)

# ── Paths ─────────────────────────────────────────────────────────────────────
REVIEWED_DOC  <- "output/report_v1_reviewed.docx"   # ← the file after human review
ORIGINAL_YAML <- "config.yaml"
OUTPUT_YAML   <- "output/config_extracted_v2.yaml"

# ── Helper: extract text from a paragraph XML node ───────────────────────────
para_text <- function(para_node) {
  ns <- xml_ns(para_node)
  runs <- xml_find_all(para_node, ".//w:t", ns)
  text <- paste(xml_text(runs), collapse = "")
  # Strip "Note: " prefix we added during generation
  text <- sub("^Note: ", "", text)
  trimws(text)
}

# ── Helper: find the paragraph that CONTAINS a given bookmark name ────────────
# Returns the paragraph xml node, or NULL if not found.
find_bookmarked_paragraph <- function(doc_xml, bookmark_name) {
  ns <- xml_ns(doc_xml)

  # Find the bookmarkStart with matching name
  bk <- xml_find_first(
    doc_xml,
    sprintf('.//w:bookmarkStart[@w:name="%s"]', bookmark_name),
    ns
  )

  if (is.na(bk) || is.null(bk)) return(NULL)

  # Walk up to parent <w:p>
  node <- bk
  while (!is.null(node) && xml_name(node) != "p") {
    node <- xml_parent(node)
  }

  if (is.null(node) || xml_name(node) != "p") return(NULL)
  node
}

# ── Helper: list all bookmark names present in the document ──────────────────
list_all_bookmarks <- function(doc_xml) {
  ns <- xml_ns(doc_xml)
  bk_nodes <- xml_find_all(doc_xml, ".//w:bookmarkStart", ns)
  names_vec <- xml_attr(bk_nodes, "name")
  names_vec[!is.na(names_vec)]
}

# ── MAIN ──────────────────────────────────────────────────────────────────────
cat("=== PopPK Report — Extract State from Reviewed Doc ===\n\n")

# Check reviewed doc exists
if (!file.exists(REVIEWED_DOC)) {
  stop(sprintf(
    "Reviewed document not found: %s\n  Please save your reviewed file there and re-run.",
    REVIEWED_DOC
  ))
}

# Load original config (to know what block IDs to expect)
cat(sprintf("Loading original config: %s\n", ORIGINAL_YAML))
orig_cfg <- read_yaml(ORIGINAL_YAML)
expected_ids <- names(orig_cfg$blocks)
cat(sprintf("  Expected block IDs: %s\n\n", paste(expected_ids, collapse = ", ")))

# Open reviewed doc and get raw XML
cat(sprintf("Opening reviewed doc: %s\n", REVIEWED_DOC))
doc <- read_docx(REVIEWED_DOC)
doc_xml <- docx_body_xml(doc)

# List all bookmarks present
all_bmarks <- list_all_bookmarks(doc_xml)
block_bmarks <- all_bmarks[grepl("^BLOCK_", all_bmarks)]
cat(sprintf("Found %d BLOCK_* bookmarks in document:\n", length(block_bmarks)))
for (b in block_bmarks) cat(sprintf("  %s\n", b))
cat("\n")

# ── Extract state for each expected block ─────────────────────────────────────
extracted_blocks <- list()
deleted_blocks   <- character(0)

for (block_id in expected_ids) {

  title_bmark <- paste0("BLOCK_TITLE_", block_id)
  foot_bmark  <- paste0("BLOCK_FOOT_",  block_id)

  title_present <- title_bmark %in% block_bmarks
  foot_present  <- foot_bmark  %in% block_bmarks

  if (!title_present && !foot_present) {
    # Block completely gone
    cat(sprintf("[DELETED] %s — neither title nor footnote bookmark found\n", block_id))
    deleted_blocks <- c(deleted_blocks, block_id)
    next
  }

  # Extract title text
  current_title <- ""
  if (title_present) {
    title_para <- find_bookmarked_paragraph(doc_xml, title_bmark)
    if (!is.null(title_para)) {
      current_title <- para_text(title_para)
    }
  }

  # Extract footnote text
  current_foot <- ""
  if (foot_present) {
    foot_para <- find_bookmarked_paragraph(doc_xml, foot_bmark)
    if (!is.null(foot_para)) {
      current_foot <- para_text(foot_para)
    }
  }

  # Compare to original
  orig_title <- orig_cfg$blocks[[block_id]]$title   %||% ""
  orig_foot  <- orig_cfg$blocks[[block_id]]$footnote %||% ""

  title_changed <- (current_title != orig_title)
  foot_changed  <- (current_foot  != orig_foot)

  status_parts <- character(0)
  if (title_changed) status_parts <- c(status_parts, "title changed")
  if (foot_changed)  status_parts <- c(status_parts, "footnote changed")
  if (length(status_parts) == 0) status_parts <- "unchanged"

  cat(sprintf("[PRESENT] %s — %s\n", block_id, paste(status_parts, collapse = ", ")))
  if (title_changed) {
    cat(sprintf("          title:    '%s'\n", current_title))
    cat(sprintf("          original: '%s'\n", orig_title))
  }
  if (foot_changed) {
    cat(sprintf("          footnote: '%s'\n", current_foot))
  }

  # Preserve original file paths (bookmarks don't track files, yaml does)
  orig_files <- orig_cfg$blocks[[block_id]]$files

  extracted_blocks[[block_id]] <- list(
    title    = current_title,
    footnote = current_foot,
    files    = orig_files
  )
}

# ── Build output YAML ─────────────────────────────────────────────────────────
out <- list(
  metadata = modifyList(orig_cfg$metadata, list(
    version          = "v2_extracted",
    extracted_from   = REVIEWED_DOC,
    extraction_date  = format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  )),
  blocks = extracted_blocks
)

if (length(deleted_blocks) > 0) {
  out$metadata$deleted_blocks <- deleted_blocks
  cat(sprintf("\nDeleted blocks recorded in metadata: %s\n",
              paste(deleted_blocks, collapse = ", ")))
}

# Write YAML
cat(sprintf("\nWriting extracted config: %s\n", OUTPUT_YAML))
dir.create(dirname(OUTPUT_YAML), recursive = TRUE, showWarnings = FALSE)
write_yaml(out, OUTPUT_YAML)

cat("\n✓ Extraction complete!\n")
cat("  Review output/config_extracted_v2.yaml\n")
cat("  Then run: Rscript scripts/03_generate_final.R\n")

# ── Utility: base R null-coalescing operator ──────────────────────────────────
`%||%` <- function(a, b) if (!is.null(a)) a else b
