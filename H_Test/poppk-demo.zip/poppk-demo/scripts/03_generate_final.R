# =============================================================================
# 03_generate_final.R
# PopPK Report Generator — Final version from extracted YAML
#
# What it does:
#   1. Reads config_extracted_v2.yaml  (output of 02_extract_yaml.R)
#   2. Opens the original template again (fresh start)
#   3. Inserts only the SURVIVING blocks (deleted ones are skipped entirely)
#   4. Uses the CURRENT title/footnote text from the extracted YAML
#        (so reviewer edits are honoured)
#   5. Saves output/report_final.docx
#
# This means the final doc reflects all reviewer decisions:
#   - Edited title/footnote  → new text used
#   - Deleted block          → placeholder left as-is or removed (see SKIP_DELETED)
#
# Requirements:
#   install.packages(c("officer", "yaml", "xml2"))
# =============================================================================

library(officer)
library(yaml)
library(xml2)

# ── Config ────────────────────────────────────────────────────────────────────
TEMPLATE_PATH  <- "PopPK_Template.docx"
EXTRACTED_YAML <- "output/config_extracted_v2.yaml"
OUTPUT_PATH    <- "output/report_final.docx"

# If TRUE, paragraphs whose block was deleted get replaced with a blank line.
# If FALSE, the {{MAGIC_STRING}} placeholder text is left visible.
SKIP_DELETED <- TRUE

# ── Helpers (same as 01_generate_v1.R) ───────────────────────────────────────
bk_counter <- new.env(parent = emptyenv())
bk_counter$n <- 200

next_bm_id <- function() {
  id <- bk_counter$n
  bk_counter$n <- bk_counter$n + 1
  id
}

add_bookmark_to_paragraph <- function(para_xml, bookmark_name) {
  id <- next_bm_id()
  ns <- "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
  start_node <- read_xml(sprintf('<w:bookmarkStart xmlns:w="%s" w:id="%d" w:name="%s"/>', ns, id, bookmark_name))
  end_node   <- read_xml(sprintf('<w:bookmarkEnd   xmlns:w="%s" w:id="%d"/>',              ns, id))
  children <- xml_children(para_xml)
  if (length(children) > 0) {
    xml_add_sibling(children[[1]], start_node, .where = "before")
    xml_add_sibling(children[[length(xml_children(para_xml))]], end_node, .where = "after")
  } else {
    xml_add_child(para_xml, start_node)
    xml_add_child(para_xml, end_node)
  }
  invisible(para_xml)
}

find_placeholder_index <- function(doc, placeholder) {
  content <- doc$content
  for (i in seq_len(nrow(content))) {
    if (!is.na(content$text[i]) && grepl(placeholder, content$text[i], fixed = TRUE)) {
      return(i)
    }
  }
  NULL
}

tag_paragraph_with_bookmark <- function(doc_xml, search_text, bookmark_name) {
  ns <- xml_ns(doc_xml)
  paras <- xml_find_all(doc_xml, ".//w:p", ns)
  for (p in paras) {
    runs <- xml_find_all(p, ".//w:t", ns)
    full_text <- paste(xml_text(runs), collapse = "")
    if (grepl(search_text, full_text, fixed = TRUE)) {
      add_bookmark_to_paragraph(p, bookmark_name)
      return(TRUE)
    }
  }
  FALSE
}

`%||%` <- function(a, b) if (!is.null(a)) a else b

# ── MAIN ──────────────────────────────────────────────────────────────────────
cat("=== PopPK Report Generator — Final ===\n\n")

if (!file.exists(EXTRACTED_YAML)) {
  stop(sprintf("Extracted YAML not found: %s\n  Run 02_extract_yaml.R first.", EXTRACTED_YAML))
}

cfg <- read_yaml(EXTRACTED_YAML)
surviving <- names(cfg$blocks)
deleted   <- cfg$metadata$deleted_blocks %||% character(0)

cat(sprintf("Blocks to insert:  %s\n", paste(surviving, collapse = ", ")))
cat(sprintf("Blocks deleted:    %s\n", if (length(deleted) > 0) paste(deleted, collapse = ", ") else "(none)"))

# Need original config to know ALL placeholder IDs (including deleted ones)
orig_cfg     <- read_yaml("config.yaml")
all_block_ids <- names(orig_cfg$blocks)

cat(sprintf("\nOpening template: %s\n", TEMPLATE_PATH))
doc <- read_docx(TEMPLATE_PATH)
base_dir <- "."

for (block_id in all_block_ids) {

  placeholder <- sprintf("{{%s}}", block_id)
  idx <- find_placeholder_index(doc, placeholder)

  if (is.null(idx)) {
    warning(sprintf("Placeholder '%s' not found — skipping", placeholder))
    next
  }

  if (block_id %in% deleted) {
    # ── Deleted block: remove placeholder, optionally leave blank ──────────
    cat(sprintf("\n[SKIP — deleted] %s\n", block_id))
    doc <- cursor_reach(doc, keyword = placeholder)
    doc <- body_remove(doc)
    if (SKIP_DELETED) {
      doc <- body_add_par(doc, value = "", style = "Normal", pos = "after")
    }
    next
  }

  # ── Surviving block: insert with current title/footnote ────────────────
  blk       <- cfg$blocks[[block_id]]
  title     <- blk$title    %||% ""
  footnote  <- blk$footnote %||% ""
  img_paths <- file.path(base_dir, unlist(blk$files))

  cat(sprintf("\n[INSERT] %s\n", block_id))
  cat(sprintf("  Title:    %s\n", substr(title, 1, 60)))
  cat(sprintf("  Footnote: %s\n", substr(footnote, 1, 60)))

  missing <- img_paths[!file.exists(img_paths)]
  if (length(missing) > 0) stop(sprintf("Missing images: %s", paste(missing, collapse = ", ")))

  doc <- cursor_reach(doc, keyword = placeholder)
  doc <- body_remove(doc)

  # Insert block
  doc <- body_add_par(doc, value = "", style = "Normal", pos = "after")   # BLOCK_START marker
  doc <- body_add_par(doc, value = title, style = "Normal", pos = "after")
  for (img in img_paths) {
    doc <- body_add_img(doc, src = img, width = 6, height = 4, pos = "after")
  }
  doc <- body_add_par(doc,
    value = if (nchar(footnote) > 0) paste0("Note: ", footnote) else "",
    style = "Normal", pos = "after"
  )
  doc <- body_add_par(doc, value = "", style = "Normal", pos = "after")   # BLOCK_END marker
}

# Apply bookmarks
cat("\nApplying bookmarks...\n")
doc_xml <- docx_body_xml(doc)

for (block_id in surviving) {
  blk      <- cfg$blocks[[block_id]]
  title    <- blk$title    %||% ""
  footnote <- blk$footnote %||% ""

  if (nchar(title) > 0) {
    ok <- tag_paragraph_with_bookmark(doc_xml, title, paste0("BLOCK_TITLE_", block_id))
    cat(sprintf("  BLOCK_TITLE_%s: %s\n", block_id, if (ok) "OK" else "NOT FOUND"))
  }
  if (nchar(footnote) > 0) {
    ok <- tag_paragraph_with_bookmark(doc_xml, paste0("Note: ", footnote), paste0("BLOCK_FOOT_", block_id))
    cat(sprintf("  BLOCK_FOOT_%s: %s\n", block_id, if (ok) "OK" else "NOT FOUND"))
  }
}

# Save
cat(sprintf("\nSaving: %s\n", OUTPUT_PATH))
print(doc, target = OUTPUT_PATH)
cat("\n✓ report_final.docx generated!\n")
